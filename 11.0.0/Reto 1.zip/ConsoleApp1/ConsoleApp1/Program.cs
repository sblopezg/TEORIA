﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Program
    {

        static void Main(string[] args)
        {
            int[] niveles = new int[5];
            int suma = 0;
            int menor = 0;
            int verdadero = 0;

            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("Ingrese número de personas por nivel:");
                niveles[i] = int.Parse(Console.ReadLine());
            }
            for (int i = 0; i < 5; i++)
            {
                suma += niveles[i];
            }
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("Nivel " + (i+1));
                Console.WriteLine(niveles[i]);
            }
            for (int i = 0; i < 5; i++)
            {
                if (menor < niveles[i])
                {
                    menor = niveles[i];
                    verdadero = i + 1;
                }
            }
            Console.WriteLine("El nivel con más personas es: "+ menor);
            Console.WriteLine("El total de personas en el edificio es: "+ suma);
            Console.ReadKey();
        }
    }
}
