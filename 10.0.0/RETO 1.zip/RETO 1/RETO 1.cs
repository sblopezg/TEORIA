using System;

class Program
{
    //funcion
    public static int alCubo ()
    {
        int num; 
        int res; 
        
        Console.WriteLine ("Ingrese el numero");
        num = Int32.Parse(Console.ReadLine());
        res = num * num * num;
        
        return res;
    }
    
    // recibir de parametro el numero a evaluar 
    public static int alCuboV2 (int num)
    {
        int res;
        res = num * num * num;
        
        return res; 
    }
    
    //bloque que se ejecuta 
    static void Main () {
        int num2;
        int resultado = alCubo();
        int num3 = 27;
        Console.WriteLine ("El resultado es "+resultado);
        Console.WriteLine ("Version 2");
        
        //1
        resultado = alCuboV2(3);
        Console.WriteLine ("El resultado es "+resultado);
        
        //2
        Console.WriteLine("Ingrese el numero");
        num2 = Int32.Parse (Console.ReadLine());
        resultado = alCuboV2(num2);
        Console.WriteLine("El resultado es "+resultado);
        //3
        resultado = alCuboV2(num3);
        Console.WriteLine("El resultado es "+resultado);
    
        
    }
}